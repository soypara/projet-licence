"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";

export default function AdminHotelsPage() {
  const [hotels, setHotels] = useState([]);
  const [places, setPlaces] = useState([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  const [form, setForm] = useState({
    name: "",
    address: "",
    tourist_place_id: "",
  });

  async function loadData() {
    try {
      setLoading(true);
      setError("");

      const [hotelsData, placesData] =
        await Promise.all([
          api.get("/hotels"),
          api.get("/tourist-places"),
        ]);

      setHotels(hotelsData || []);
      setPlaces(placesData || []);
    } catch (err) {
      setError(
        err.message ||
          "Impossible de charger les hôtels."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  function handleChange(e) {
    setForm((current) => ({
      ...current,
      [e.target.name]: e.target.value,
    }));
  }

  async function handleCreate(e) {
    e.preventDefault();

    if (!form.name.trim()) {
      setError("Le nom de l'hôtel est obligatoire.");
      return;
    }

    if (!form.address.trim()) {
      setError("L'adresse est obligatoire.");
      return;
    }

    try {
      setSaving(true);
      setError("");

      await api.post("/hotels", {
        name: form.name.trim(),
        address: form.address.trim(),
        ...(form.tourist_place_id
          ? {
              tourist_place_id:
                form.tourist_place_id,
            }
          : {}),
      });

      setForm({
        name: "",
        address: "",
        tourist_place_id: "",
      });

      await loadData();
    } catch (err) {
      setError(
        err.message ||
          "Impossible de créer l'hôtel."
      );
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id) {
    if (
      !window.confirm(
        "Supprimer cet hôtel ?"
      )
    ) {
      return;
    }

    try {
      await api.del(`/hotels/${id}`);

      setHotels((current) =>
        current.filter(
          (hotel) => hotel.id !== id
        )
      );
    } catch (err) {
      setError(err.message);
    }
  }

  const filteredHotels = hotels.filter(
    (hotel) => {
      const query =
        search.toLowerCase();

      return (
        hotel.name
          ?.toLowerCase()
          .includes(query) ||
        hotel.address
          ?.toLowerCase()
          .includes(query)
      );
    }
  );

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold sm:text-3xl">
          Hôtels
        </h1>

        <p className="mt-1 text-sm text-gray-500">
          Gestion des hébergements touristiques.
        </p>
      </div>

      {error && (
        <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
        </div>
      )}

      <section className="mb-8 rounded-2xl border bg-white p-4 shadow-sm sm:p-6">
        <h2 className="text-lg font-semibold">
          Ajouter un hôtel
        </h2>

        <form
          onSubmit={handleCreate}
          className="mt-4 grid gap-4"
        >
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Nom de l'hôtel"
            className="w-full rounded-xl border px-4 py-3 text-sm"
          />

          <input
            name="address"
            value={form.address}
            onChange={handleChange}
            placeholder="Adresse"
            className="w-full rounded-xl border px-4 py-3 text-sm"
          />

          <select
            name="tourist_place_id"
            value={form.tourist_place_id}
            onChange={handleChange}
            className="w-full rounded-xl border bg-white px-4 py-3 text-sm"
          >
            <option value="">
              Aucun lieu associé
            </option>

            {places.map((place) => (
              <option
                key={place.id}
                value={place.id}
              >
                {place.name}
              </option>
            ))}
          </select>

          <button
            disabled={saving}
            className="w-full rounded-xl bg-green-700 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50 sm:w-fit"
          >
            {saving
              ? "Création..."
              : "Créer l'hôtel"}
          </button>
        </form>
      </section>

      <section className="rounded-2xl border bg-white p-4 shadow-sm sm:p-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h2 className="text-lg font-semibold">
              Hôtels existants
            </h2>

            <p className="text-sm text-gray-500">
              {hotels.length} hôtel(s)
            </p>
          </div>

          <input
            type="search"
            value={search}
            onChange={(e) =>
              setSearch(e.target.value)
            }
            placeholder="Rechercher..."
            className="w-full rounded-xl border px-4 py-3 text-sm sm:max-w-xs"
          />
        </div>

        {loading ? (
          <p className="py-10 text-center text-sm text-gray-500">
            Chargement...
          </p>
        ) : (
          <div className="mt-6 space-y-3">
            {filteredHotels.map((hotel) => (
              <article
                key={hotel.id}
                className="flex flex-col gap-3 rounded-xl border p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <h3 className="font-semibold">
                    {hotel.name}
                  </h3>

                  <p className="mt-1 text-sm text-gray-500">
                    {hotel.address}
                  </p>
                </div>

                <button
                  onClick={() =>
                    handleDelete(hotel.id)
                  }
                  className="rounded-lg bg-red-50 px-3 py-2 text-sm font-medium text-red-700"
                >
                  Supprimer
                </button>
              </article>
            ))}

            {filteredHotels.length === 0 && (
              <p className="py-10 text-center text-sm text-gray-500">
                Aucun hôtel trouvé.
              </p>
            )}
          </div>
        )}
      </section>
    </div>
  );
}
