"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";

export default function AdminPage() {
  const [stats, setStats] = useState({
    places: 0,
    circuits: 0,
    hotels: 0,
    comments: 0,
  });

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadStats() {
      try {
        const [
          places,
          circuits,
          hotels,
          comments,
        ] = await Promise.all([
          api.get("/tourist-places"),
          api.get("/circuits"),
          api.get("/hotels"),
          api.get("/comments/admin"),
        ]);

        setStats({
          places: places?.length || 0,
          circuits: circuits?.length || 0,
          hotels: hotels?.length || 0,
          comments: comments?.length || 0,
        });
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    }

    loadStats();
  }, []);

  const cards = [
    {
      label: "Lieux touristiques",
      value: stats.places,
      href: "/admin/places",
    },
    {
      label: "Circuits",
      value: stats.circuits,
      href: "/admin/circuits",
    },
    {
      label: "Hôtels",
      value: stats.hotels,
      href: "/admin/hotels",
    },
    {
      label: "Commentaires",
      value: stats.comments,
      href: "/admin/comments",
    },
  ];

  return (
    <div className="mx-auto max-w-7xl">
      <h1 className="text-2xl font-bold sm:text-3xl">
        Dashboard
      </h1>

      <p className="mt-2 text-sm text-gray-500">
        Vue générale de Madagascar Tour.
      </p>

      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((card) => (
          <Link
            key={card.label}
            href={card.href}
            className="rounded-2xl border bg-white p-4 shadow-sm transition hover:shadow-md"
          >
            <p className="text-sm text-gray-500">
              {card.label}
            </p>

            <p className="mt-2 text-2xl font-bold">
              {loading ? "…" : card.value}
            </p>
          </Link>
        ))}
      </div>
    </div>
  );
}
