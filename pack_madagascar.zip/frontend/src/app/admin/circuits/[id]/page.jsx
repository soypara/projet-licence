"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { api } from "@/lib/api";

export default function CircuitDetailPage() {
  const params = useParams();
  const id = params.id;

  const [circuit, setCircuit] = useState(null);
  const [places, setPlaces] = useState([]);
  const [hotels, setHotels] = useState([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    title: "",
    description: "",
    price: "",
  });

  async function loadData() {
    try {
      setLoading(true);
      setError("");

      const [
        circuitData,
        placesData,
        hotelsData,
      ] = await Promise.all([
        api.get(`/circuits/${id}`),
        api.get("/tourist-places"),
        api.get("/hotels"),
      ]);

      setCircuit(circuitData);
      setPlaces(placesData || []);
      setHotels(hotelsData || []);

      setForm({
        title: circuitData.title || "",
        description:
          circuitData.description || "",
        price: circuitData.price || "",
      });
    } catch (err) {
      setError(
        err.message ||
          "Impossible de charger le circuit."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (id) {
      loadData();
    }
  }, [id]);

  async function handleSave(e) {
    e.preventDefault();

    try {
      setSaving(true);
      setError("");

      await api.put(`/circuits/${id}`, {
        title: form.title.trim(),
        description:
          form.description.trim(),
        price: Number(form.price),
      });

      await loadData();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function addPlace(placeId) {
    try {
      await api.post(
        `/circuits/${id}/places/${placeId}`,
        {}
      );

      await loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function removePlace(placeId) {
    try {
      await api.del(
        `/circuits/${id}/places/${placeId}`
      );

      await loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function addHotel(hotelId) {
    try {
      await api.post(
        `/circuits/${id}/hotels/${hotelId}`,
        {}
      );

      await loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  async function removeHotel(hotelId) {
    try {
      await api.del(
        `/circuits/${id}/hotels/${hotelId}`
      );

      await loadData();
    } catch (err) {
      setError(err.message);
    }
  }

  if (loading) {
    return (
      <div className="py-10 text-center">
        Chargement...
      </div>
    );
  }

  if (!circuit) {
    return (
      <div className="py-10 text-center">
        Circuit introuvable.
      </div>
    );
  }

  const linkedPlaces =
    circuit.circuit_places || [];

  const linkedHotels =
    circuit.circuit_hotels || [];

  const linkedPlaceIds =
    linkedPlaces.map(
      (item) => item.tourist_places?.id
    );

  const linkedHotelIds =
    linkedHotels.map(
      (item) => item.hotels?.id
    );

  return (
    <div className="mx-auto max-w-7xl">
      <Link
        href="/admin/circuits"
        className="text-sm text-green-700"
      >
        ← Retour aux circuits
      </Link>

      <div className="mb-6 mt-4">
        <h1 className="text-2xl font-bold sm:text-3xl">
          {circuit.title}
        </h1>
      </div>

      {error && (
        <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
        </div>
      )}

      <section className="rounded-2xl border bg-white p-4 shadow-sm sm:p-6">
        <h2 className="text-lg font-semibold">
          Informations
        </h2>

        <form
          onSubmit={handleSave}
          className="mt-4 grid gap-4"
        >
          <input
            value={form.title}
            onChange={(e) =>
              setForm({
                ...form,
                title: e.target.value,
              })
            }
            className="rounded-xl border px-4 py-3"
          />

          <textarea
            value={form.description}
            onChange={(e) =>
              setForm({
                ...form,
                description:
                  e.target.value,
              })
            }
            rows={5}
            className="rounded-xl border px-4 py-3"
          />

          <input
            type="number"
            min="0"
            value={form.price}
            onChange={(e) =>
              setForm({
                ...form,
                price: e.target.value,
              })
            }
            className="rounded-xl border px-4 py-3"
          />

          <button
            disabled={saving}
            className="w-full rounded-xl bg-green-700 px-4 py-3 font-semibold text-white sm:w-fit"
          >
            {saving
              ? "Enregistrement..."
              : "Enregistrer"}
          </button>
        </form>
      </section>

      <section className="mt-6 rounded-2xl border bg-white p-4 shadow-sm sm:p-6">
        <h2 className="text-lg font-semibold">
          Lieux associés
        </h2>

        <div className="mt-4 space-y-3">
          {places.map((place) => {
            const linked =
              linkedPlaceIds.includes(place.id);

            return (
              <div
                key={place.id}
                className="flex flex-col gap-3 rounded-xl border p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <span className="font-medium">
                  {place.name}
                </span>

                {linked ? (
                  <button
                    onClick={() =>
                      removePlace(place.id)
                    }
                    className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"
                  >
                    Retirer
                  </button>
                ) : (
                  <button
                    onClick={() =>
                      addPlace(place.id)
                    }
                    className="rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700"
                  >
                    Ajouter
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </section>

      <section className="mt-6 rounded-2xl border bg-white p-4 shadow-sm sm:p-6">
        <h2 className="text-lg font-semibold">
          Hôtels associés
        </h2>

        <div className="mt-4 space-y-3">
          {hotels.map((hotel) => {
            const linked =
              linkedHotelIds.includes(hotel.id);

            return (
              <div
                key={hotel.id}
                className="flex flex-col gap-3 rounded-xl border p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div>
                  <p className="font-medium">
                    {hotel.name}
                  </p>

                  <p className="text-sm text-gray-500">
                    {hotel.address}
                  </p>
                </div>

                {linked ? (
                  <button
                    onClick={() =>
                      removeHotel(hotel.id)
                    }
                    className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700"
                  >
                    Retirer
                  </button>
                ) : (
                  <button
                    onClick={() =>
                      addHotel(hotel.id)
                    }
                    className="rounded-lg bg-green-50 px-3 py-2 text-sm text-green-700"
                  >
                    Ajouter
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
