"use client";

import { useEffect, useState } from "react";
import { api } from "@/lib/api";

export default function AdminCommentsPage() {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadComments() {
    try {
      setLoading(true);
      setError("");

      const data =
        await api.get("/comments/admin");

      setComments(data || []);
    } catch (err) {
      setError(
        err.message ||
          "Impossible de charger les commentaires."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadComments();
  }, []);

  async function updateStatus(id, status) {
    try {
      await api.put(
        `/comments/${id}/status`,
        { status }
      );

      setComments((current) =>
        current.map((comment) =>
          comment.id === id
            ? { ...comment, status }
            : comment
        )
      );
    } catch (err) {
      setError(err.message);
    }
  }

  async function remove(id) {
    if (
      !window.confirm(
        "Supprimer ce commentaire ?"
      )
    ) {
      return;
    }

    try {
      await api.del(`/comments/${id}`);

      setComments((current) =>
        current.filter(
          (comment) => comment.id !== id
        )
      );
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6">
        <h1 className="text-2xl font-bold sm:text-3xl">
          Commentaires
        </h1>

        <p className="mt-1 text-sm text-gray-500">
          Modération des avis des utilisateurs.
        </p>
      </div>

      {error && (
        <div className="mb-6 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
          {error}
        </div>
      )}

      <section className="rounded-2xl border bg-white p-4 shadow-sm sm:p-6">
        {loading ? (
          <p className="py-10 text-center text-sm text-gray-500">
            Chargement...
          </p>
        ) : comments.length === 0 ? (
          <p className="py-10 text-center text-sm text-gray-500">
            Aucun commentaire.
          </p>
        ) : (
          <div className="space-y-4">
            {comments.map((comment) => (
              <article
                key={comment.id}
                className="rounded-xl border p-4"
              >
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">
                        {"★".repeat(
                          comment.rating || 0
                        )}
                      </span>

                      <span className="text-xs text-gray-500">
                        {comment.status}
                      </span>
                    </div>

                    <p className="mt-2 text-sm text-gray-700">
                      {comment.content}
                    </p>

                    <p className="mt-2 text-xs text-gray-500">
                      {comment.tourist_places?.name ||
                        comment.circuits?.title ||
                        "Cible inconnue"}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {comment.status !==
                      "approved" && (
                      <button
                        onClick={() =>
                          updateStatus(
                            comment.id,
                            "approved"
                          )
                        }
                        className="rounded-lg bg-green-50 px-3 py-2 text-xs font-medium text-green-700"
                      >
                        Approuver
                      </button>
                    )}

                    {comment.status !==
                      "rejected" && (
                      <button
                        onClick={() =>
                          updateStatus(
                            comment.id,
                            "rejected"
                          )
                        }
                        className="rounded-lg bg-orange-50 px-3 py-2 text-xs font-medium text-orange-700"
                      >
                        Rejeter
                      </button>
                    )}

                    <button
                      onClick={() =>
                        remove(comment.id)
                      }
                      className="rounded-lg bg-red-50 px-3 py-2 text-xs font-medium text-red-700"
                    >
                      Supprimer
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
