import { SupabaseClient } from "@supabase/supabase-js";
import { supabase } from "../config/supabase";
import { AppError } from "../middlewares/errorHandler";
import { CircuitInput } from "../schemas/circuit.schema";

export async function listCircuits() {
  const { data, error } = await supabase
    .from("circuits")
    .select(`
      *,
      tourist_places (
        id,
        name
      )
    `)
    .order("created_at", { ascending: false });

  if (error) {
    throw new AppError(error.message, 500);
  }

  return data;
}

export async function getCircuitById(id: string) {
  const { data, error } = await supabase
    .from("circuits")
    .select(`
      *,
      tourist_places (
        id,
        name
      ),
      circuit_places (
        tourist_places (*)
      ),
      circuit_hotels (
        hotels (*)
      )
    `)
    .eq("id", id)
    .single();

  if (error) {
    throw new AppError(
      "Circuit introuvable.",
      404
    );
  }

  return data;
}

export async function createCircuit(
  client: SupabaseClient,
  input: CircuitInput
) {
  const { data, error } = await client
    .from("circuits")
    .insert(input)
    .select()
    .single();

  if (error) {
    throw new AppError(error.message, 500);
  }

  return data;
}

export async function updateCircuit(
  client: SupabaseClient,
  id: string,
  input: Partial<CircuitInput>
) {
  const { data, error } = await client
    .from("circuits")
    .update(input)
    .eq("id", id)
    .select()
    .single();

  if (error) {
    throw new AppError(error.message, 500);
  }

  if (!data) {
    throw new AppError(
      "Circuit introuvable.",
      404
    );
  }

  return data;
}

export async function deleteCircuit(
  client: SupabaseClient,
  id: string
) {
  const { error } = await client
    .from("circuits")
    .delete()
    .eq("id", id);

  if (error) {
    throw new AppError(error.message, 500);
  }
}

export async function attachTouristPlace(
  client: SupabaseClient,
  circuitId: string,
  touristPlaceId: string
) {
  const { error } = await client
    .from("circuit_places")
    .insert({
      circuit_id: circuitId,
      tourist_place_id: touristPlaceId,
    });

  if (error) {
    throw new AppError(error.message, 500);
  }
}

export async function detachTouristPlace(
  client: SupabaseClient,
  circuitId: string,
  touristPlaceId: string
) {
  const { error } = await client
    .from("circuit_places")
    .delete()
    .eq("circuit_id", circuitId)
    .eq("tourist_place_id", touristPlaceId);

  if (error) {
    throw new AppError(error.message, 500);
  }
}

export async function attachHotel(
  client: SupabaseClient,
  circuitId: string,
  hotelId: string
) {
  const { error } = await client
    .from("circuit_hotels")
    .insert({
      circuit_id: circuitId,
      hotel_id: hotelId,
    });

  if (error) {
    throw new AppError(error.message, 500);
  }
}

export async function detachHotel(
  client: SupabaseClient,
  circuitId: string,
  hotelId: string
) {
  const { error } = await client
    .from("circuit_hotels")
    .delete()
    .eq("circuit_id", circuitId)
    .eq("hotel_id", hotelId);

  if (error) {
    throw new AppError(error.message, 500);
  }
}
