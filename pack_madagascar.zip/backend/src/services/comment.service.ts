import { SupabaseClient } from "@supabase/supabase-js";
import { supabase } from "../config/supabase";
import { AppError } from "../middlewares/errorHandler";
import { CommentInput } from "../schemas/comment.schema";

// MODIFIÉ : reçoit le client authentifié (sinon la RLS ne montre que
// les commentaires approuvés et la modération ne verrait aucun "pending").
export async function listComments(client: SupabaseClient) {
  const { data, error } = await client
    .from("comments")
    .select(`
      *,
      tourist_places (
        id,
        name
      ),
      circuits (
        id,
        title
      )
    `)
    .order("created_at", { ascending: false });

  if (error) {
    throw new AppError(error.message, 500);
  }

  return data;
}

export async function listApprovedComments(
  touristPlaceId?: string,
  circuitId?: string
) {
  let query = supabase
    .from("comments")
    .select(`
      *,
      tourist_places (
        id,
        name
      ),
      circuits (
        id,
        title
      )
    `)
    .eq("status", "approved")
    .order("created_at", { ascending: false });

  if (touristPlaceId) {
    query = query.eq("tourist_place_id", touristPlaceId);
  }

  if (circuitId) {
    query = query.eq("circuit_id", circuitId);
  }

  const { data, error } = await query;

  if (error) {
    throw new AppError(error.message, 500);
  }

  return data;
}

export async function createComment(
  client: SupabaseClient,
  userId: string,
  input: CommentInput
) {
  const { data, error } = await client
    .from("comments")
    .insert({
      user_id: userId,
      content: input.content,
      rating: input.rating,
      tourist_place_id: input.tourist_place_id ?? null,
      circuit_id: input.circuit_id ?? null,
      status: "pending",
    })
    .select()
    .single();

  if (error) {
    throw new AppError(error.message, 500);
  }

  return data;
}

export async function updateComment(
  client: SupabaseClient,
  id: string,
  input: Partial<CommentInput>
) {
  const { data, error } = await client
    .from("comments")
    .update(input)
    .eq("id", id)
    .select()
    .single();

  if (error) {
    throw new AppError(error.message, 500);
  }

  if (!data) {
    throw new AppError("Commentaire introuvable.", 404);
  }

  return data;
}

export async function updateCommentStatus(
  client: SupabaseClient,
  id: string,
  status: "pending" | "approved" | "rejected"
) {
  const { data, error } = await client
    .from("comments")
    .update({ status })
    .eq("id", id)
    .select()
    .single();

  if (error) {
    throw new AppError(error.message, 500);
  }

  if (!data) {
    throw new AppError("Commentaire introuvable.", 404);
  }

  return data;
}

export async function deleteComment(
  client: SupabaseClient,
  id: string
) {
  const { error } = await client
    .from("comments")
    .delete()
    .eq("id", id);

  if (error) {
    throw new AppError(error.message, 500);
  }
}
