import { z } from "zod";

export const circuitSchema = z.object({
  title: z
    .string()
    .min(
      3,
      "Le titre doit contenir au moins 3 caractères."
    ),

  description: z
    .string()
    .min(
      10,
      "La description doit contenir au moins 10 caractères."
    ),

  price: z
    .number()
    .nonnegative(
      "Le prix ne peut pas être négatif."
    ),

  tourist_place_id: z
    .string()
    .uuid()
    .optional(),
});

export const circuitUpdateSchema =
  circuitSchema.partial();

export type CircuitInput =
  z.infer<typeof circuitSchema>;
