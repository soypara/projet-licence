import { Router } from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { authenticate } from "../middlewares/auth.middleware";
import { validateBody } from "../middlewares/validate";

import {
  circuitSchema,
  circuitUpdateSchema,
} from "../schemas/circuit.schema";

import * as circuitController from "../controllers/circuit.controller";

const router = Router();

router.get(
  "/",
  asyncHandler(circuitController.getAll)
);

router.get(
  "/:id",
  asyncHandler(circuitController.getOne)
);

router.post(
  "/",
  authenticate,
  validateBody(circuitSchema),
  asyncHandler(circuitController.create)
);

router.put(
  "/:id",
  authenticate,
  validateBody(circuitUpdateSchema),
  asyncHandler(circuitController.update)
);

router.delete(
  "/:id",
  authenticate,
  asyncHandler(circuitController.remove)
);

router.post(
  "/:id/places/:placeId",
  authenticate,
  asyncHandler(circuitController.linkTouristPlace)
);

router.delete(
  "/:id/places/:placeId",
  authenticate,
  asyncHandler(circuitController.unlinkTouristPlace)
);

router.post(
  "/:id/hotels/:hotelId",
  authenticate,
  asyncHandler(circuitController.linkHotel)
);

router.delete(
  "/:id/hotels/:hotelId",
  authenticate,
  asyncHandler(circuitController.unlinkHotel)
);

export default router;
