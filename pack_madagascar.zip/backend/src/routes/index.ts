import { Router } from "express";

import circuitRoutes from "./circuit.routes";
import touristPlaceRoutes from "./touristPlace.routes";
import hotelRoutes from "./hotel.routes";
import mediaRoutes from "./media.routes";
import wikipediaRoutes from "./wikipedia.routes";
import placeSearchRoutes from "./placeSearch.routes";
import commentRoutes from "./comment.routes";

const router = Router();

router.use("/circuits", circuitRoutes);
router.use("/tourist-places", touristPlaceRoutes);
router.use("/hotels", hotelRoutes);
router.use("/media", mediaRoutes);
router.use("/wikipedia", wikipediaRoutes);
router.use("/place-search", placeSearchRoutes);
router.use("/comments", commentRoutes);

export default router;
